# Waypoint Home

1. Upload this folder to a GitHub repository.
2. Enable GitHub Pages in Settings > Pages.
3. Replace the Google Calendar link in index.html with your booking link.
4. Add your own images into the images folder.
